module.exports = {
    require: {
        persianDate: require('./dist/persian-date')
    },
    globals: {
        persianDate: require('./dist/persian-date')
    }
}