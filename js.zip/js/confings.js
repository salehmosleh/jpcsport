var config = {
	google_api_server: 'https://www.googleapis.com/calendar/v3/calendars/jpcomplex.sports@gmail.com/events',
	api_key: 'AIzaSyDF5LhZQ-r_tITY8CZECuomZFRiMBvOmto'
};